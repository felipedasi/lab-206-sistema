<?php
	$servidor = "localhost";
	$usuario = "id8251544_felipe";
	$senha = "132010";
	$dbname = "id8251544_db";
	
	//Criar a conexão
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
	if(!$conn){
		die("Falha na conexao: " . mysqli_connect_error());
	}else{
		//echo "Conexao realizada com sucesso";
	}
?>